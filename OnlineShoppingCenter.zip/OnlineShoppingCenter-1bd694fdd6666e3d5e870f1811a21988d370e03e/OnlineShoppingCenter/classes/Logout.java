package classes;

public class Logout
{
	public void Logout_message()
  	{
	   System.out.print("\n  You have successfully logged out !!");	
           System.out.print("\n\n  Thank you for shopping with us");
      	}
}
